@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h2 class="mb-4 text-success">📱 สินค้าที่สามารถผ่อนชำระได้</h2>

    <div class="row">
        @foreach($products as $product)
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <img src="{{ asset('storage/products/' . $product->product_image) }}" class="card-img-top" alt="{{ $product->product_name }}">
                    <div class="card-body">
                        <h5 class="card-title">{{ $product->product_name }}</h5>
                        <p class="card-text text-success">
                            ราคา: {{ number_format($product->price, 2) }} บาท
                        </p>
                        <p class="card-text">
                            ผ่อนนานสูงสุด: {{ $product->installment_months }} เดือน
                        </p>
                        <a href="{{ route('installments.request.create', $product->id) }}" class="btn btn-success">ผ่อนสินค้า</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
