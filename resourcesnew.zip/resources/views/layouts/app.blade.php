<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Bootstrap CDN (ถ้ามีอยู่แล้วไม่ต้องเพิ่มซ้ำ) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS สำหรับธีม KPLUS -->
    <link href="{{ asset('css/custom.css') }}" rel="stylesheet">

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-50">
    <nav class="bg-kplus-green text-white shadow">
        <div class="container mx-auto px-4 py-4 flex justify-between items-center">
            <a href="/" class="font-bold text-lg">KPLUS ผ่อนง่าย</a>

            <button id="mobile-menu-btn" class="sm:hidden text-2xl">☰</button>

            <div id="desktop-menu" class="hidden sm:flex space-x-4 items-center">
            <a href="/" class="text-lg">หน้าแรก</a>
            <a href="/gold" class="text-lg">ผ่อนทอง</a>
            <a href="/phone" class="text-lg">ผ่อนมือถือ</a>
            <a href="/contact" class="text-lg">ติดต่อเรา</a>
            @if(Auth::check())
                <a href="{{ route('user.installments.index') }}" class="text-lg">📱 คำขอผ่อนของฉัน</a>
                <form action="{{ route('logout') }}" method="POST" class="inline-block">
                    @csrf
                    <button type="submit" class="btn btn-outline-light btn-sm rounded-pill">
                        ออกจากระบบ
                    </button>
                </form>
            @else
                <a href="{{ route('login') }}" class="text-lg">เข้าสู่ระบบ</a>
            @endif
            </div>
        </div>

        <div id="mobile-menu" class="hidden sm:hidden flex flex-col px-4 pb-4 space-y-2 text-lg overflow-hidden transition-height">
            <a href="/" class="block py-2 px-3 hover:bg-green-700 rounded-lg">หน้าแรก</a>
            <a href="/gold" class="block py-2 px-3 hover:bg-green-700 rounded-lg">ผ่อนทอง</a>
            <a href="/phone" class="block py-2 px-3 hover:bg-green-700 rounded-lg">ผ่อนมือถือ</a>
            <a href="/contact" class="block py-2 px-3 hover:bg-green-700 rounded-lg">ติดต่อเรา</a>
            @if(Auth::check())
                <a href="{{ route('user.installments.index') }}" class="block py-2 px-3 hover:bg-green-700 rounded-lg">
                    📱 คำขอผ่อนของฉัน
                </a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="btn btn-outline-light btn-sm rounded-pill w-full mt-2">
                        ออกจากระบบ
                    </button>
                </form>
            @else
                <a href="{{ route('login') }}" class="block py-2 px-3 hover:bg-green-700 rounded-lg">เข้าสู่ระบบ</a>
            @endif
        </div>
    </nav>

    <script>
        const btn = document.getElementById('mobile-menu-btn');
        const menu = document.getElementById('mobile-menu');
        const contentWrapper = document.getElementById('content-wrapper');

        btn.addEventListener('click', () => {
            if (menu.classList.contains('active')) {
                menu.style.height = '0px';
                if (contentWrapper) contentWrapper.style.marginTop = '2rem';
                menu.classList.remove('active');

                setTimeout(() => {
                    menu.classList.add('hidden');
                }, 500);

            } else {
                menu.classList.remove('hidden');
                const height = menu.scrollHeight;
                
                setTimeout(() => {
                    menu.style.height = `${height}px`;
                    if (contentWrapper) contentWrapper.style.marginTop = `${height}px`;
                }, 10);

                menu.classList.add('active');
            }
        });
    </script>

     <div id="content-wrapper" class="container mx-auto my-8 px-4 sm:px-6 lg:px-8 transition-all">
        @yield('content')
    </div>

</body>
</html>
