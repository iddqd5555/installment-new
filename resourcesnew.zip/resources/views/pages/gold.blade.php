@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto bg-white p-6 shadow-lg rounded-lg">
    <h2 class="text-xl sm:text-2xl font-bold text-kplus-green mb-4">รายการทองที่สามารถผ่อนได้</h2>

    <div class="text-gray-600">
        <p>ยังไม่มีรายการทองที่สามารถผ่อนได้ในขณะนี้</p>
    </div>
</div>
@endsection
