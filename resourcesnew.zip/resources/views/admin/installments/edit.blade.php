@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h3 class="mb-4">แก้ไขคำขอผ่อนสินค้า</h3>

    <form action="{{ route('admin.installments.update', $request->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label class="form-label">ชื่อสินค้า</label>
            <input type="text" name="product_name" class="form-control" value="{{ $request->product_name }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">ราคาขาย (บาท)</label>
            <input type="number" name="price" step="0.01" class="form-control" value="{{ $request->price }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">ราคาต้นทุน (บาท)</label>
            <input type="number" name="product_price" step="0.01" class="form-control" value="{{ $request->product_price }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">จำนวนเดือนผ่อน</label>
            <input type="number" name="installment_months" class="form-control" value="{{ $request->installment_months }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">รูปสินค้า (หากต้องการเปลี่ยน)</label>
            <input type="file" name="product_image" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">สถานะ</label>
            <select name="status" class="form-select">
                <option value="pending" {{ $request->status == 'pending' ? 'selected' : '' }}>รอดำเนินการ</option>
                <option value="approved" {{ $request->status == 'approved' ? 'selected' : '' }}>อนุมัติ</option>
                <option value="rejected" {{ $request->status == 'rejected' ? 'selected' : '' }}>ปฏิเสธ</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">อัปเดตข้อมูล</button>
        <a href="{{ route('admin.installments.index') }}" class="btn btn-secondary">ย้อนกลับ</a>
    </form>
</div>
@endsection
