@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-success">📱 รายการคำขอผ่อนสินค้า (Admin)</h2>
        <a href="{{ route('admin.installments.create') }}" class="btn btn-success">➕ เพิ่มสินค้าใหม่</a>
    </div>

    <!-- ตารางแสดงรายการรออนุมัติ -->
    <div class="card mb-5">
        <div class="card-header bg-warning text-dark">
            <h5>📌 คำขอที่รออนุมัติ</h5>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead class="table-warning">
                    <tr>
                        <th>ID</th>
                        <th>สินค้า</th>
                        <th>ราคา</th>
                        <th>ผู้ขอผ่อน (User ID)</th>
                        <th class="text-center">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($requests->where('status', 'pending') as $installment)
                        <tr>
                            <td>{{ $installment->id }}</td>
                            <td>{{ $installment->product_name }}</td>
                            <td>{{ number_format($installment->price, 2) }} บาท</td>
                            <td>{{ $installment->user->name }}</td>
                            <td class="text-center">
                                <form action="{{ route('admin.installments.updateStatus', $installment->id) }}" method="POST">
                                    @csrf
                                    @method('PATCH')
                                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                        <option value="pending" selected>รออนุมัติ</option>
                                        <option value="approved">อนุมัติ</option>
                                        <option value="rejected">ปฏิเสธ</option>
                                    </select>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    @if($requests->where('status', 'pending')->isEmpty())
                        <tr>
                            <td colspan="5" class="text-center">ไม่มีคำขอรออนุมัติ</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>

    <!-- ตารางแสดงรายการทั้งหมด -->
    <div class="card">
        <div class="card-header bg-success text-white">
            <h5>📋 รายการทั้งหมด</h5>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead class="table-success">
                    <tr>
                        <th>ID</th>
                        <th>สินค้า</th>
                        <th>ราคา</th>
                        <th>สถานะ</th>
                        <th>ผู้ขอผ่อน (User ID)</th>
                        <th class="text-center">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($requests as $installment)
                        <tr>
                            <td>{{ $installment->id }}</td>
                            <td>{{ $installment->product_name }}</td>
                            <td>{{ number_format($installment->price, 2) }} บาท</td>
                            <td>
                                <form action="{{ route('admin.installments.updateStatus', $installment->id) }}" method="POST">
                                    @csrf
                                    @method('PATCH')
                                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                        <option value="pending" {{ $installment->status == 'pending' ? 'selected' : '' }}>รออนุมัติ</option>
                                        <option value="approved" {{ $installment->status == 'approved' ? 'selected' : '' }}>อนุมัติแล้ว</option>
                                        <option value="rejected" {{ $installment->status == 'rejected' ? 'selected' : '' }}>ปฏิเสธ</option>
                                    </select>
                                </form>
                            </td>
                            <td>{{ $installment->user->name }}</td>
                            <td class="text-center">
                                <a href="{{ route('admin.installments.edit', $installment->id) }}" class="btn btn-sm btn-primary">แก้ไข</a>
                                <form action="{{ route('admin.installments.destroy', $installment->id) }}" method="POST" class="d-inline-block">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger">ลบ</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    @if($requests->isEmpty())
                        <tr>
                            <td colspan="6" class="text-center">ไม่มีรายการข้อมูล</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
