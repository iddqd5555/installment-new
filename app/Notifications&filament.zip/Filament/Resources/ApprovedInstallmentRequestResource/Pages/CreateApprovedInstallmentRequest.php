<?php

namespace App\Filament\Resources\ApprovedInstallmentRequestResource\Pages;

use App\Filament\Resources\ApprovedInstallmentRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateApprovedInstallmentRequest extends CreateRecord
{
    protected static string $resource = ApprovedInstallmentRequestResource::class;
}
