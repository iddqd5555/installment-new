<?php

namespace App\Filament\Resources\PaymentQrLogResource\Pages;

use App\Filament\Resources\PaymentQrLogResource;
use Filament\Resources\Pages\ListRecords;

class ListPaymentQrLogs extends ListRecords
{
    protected static string $resource = PaymentQrLogResource::class;
}
