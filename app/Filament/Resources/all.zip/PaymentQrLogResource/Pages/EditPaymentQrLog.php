<?php

namespace App\Filament\Resources\PaymentQrLogResource\Pages;

use App\Filament\Resources\PaymentQrLogResource;
use Filament\Resources\Pages\EditRecord;

class EditPaymentQrLog extends EditRecord
{
    protected static string $resource = PaymentQrLogResource::class;
}
