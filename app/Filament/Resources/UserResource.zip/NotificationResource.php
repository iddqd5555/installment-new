<?php

namespace App\Filament\Resources;

use App\Filament\Resources\NotificationResource\Pages;
use App\Models\Notification;
use Filament\Forms;
use Filament\Tables;
use Filament\Resources\Resource;

class NotificationResource extends Resource
{
    protected static ?string $model = Notification::class;
    protected static ?string $navigationIcon = 'heroicon-o-bell-alert';

    public static function form(Forms\Form $form): Forms\Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('title')->required(),
            Forms\Components\Textarea::make('message')->required(),
            Forms\Components\Select::make('type')
                ->options([
                    'payment' => 'แจ้งเตือนงวดผ่อน',
                    'slip' => 'แจ้งเตือนสลิป',
                    'announce' => 'ประกาศ',
                    'other' => 'อื่นๆ',
                ])
                ->required(),
            Forms\Components\Select::make('role')
                ->options([
                    'user' => 'ลูกค้า',
                    'admin' => 'ผู้บริหาร',
                ])
                ->required(),
            Forms\Components\TextInput::make('user_id')->numeric()->nullable(),
        ]);
    }

    public static function table(Tables\Table $table): Tables\Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('title')->sortable()->searchable(),
            Tables\Columns\TextColumn::make('role')->label('กลุ่มผู้รับ'),
            Tables\Columns\TextColumn::make('type')->label('ประเภท'),
            Tables\Columns\TextColumn::make('created_at')->dateTime(),
            Tables\Columns\IconColumn::make('read_at')
                ->boolean()
                ->label('อ่านแล้ว'),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListNotifications::route('/'),
            'create' => Pages\CreateNotification::route('/create'),
            'edit' => Pages\EditNotification::route('/{record}/edit'),
        ];
    }
}
