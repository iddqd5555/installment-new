<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\InstallmentRequest;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardApiController extends Controller
{
    public function dashboardData(Request $request)
    {
        try {
            $user = Auth::user();

            if (!$user) {
                return response()->json(['contracts' => []], 401);
            }

            $installments = InstallmentRequest::with('installmentPayments')
                ->where('user_id', $user->id)
                ->where('status', 'approved')
                ->orderByDesc('id')
                ->get();

            // ตอบกลับแบบนี้เสมอ จะไม่บั๊ก Flutter
            if ($installments->isEmpty()) {
                return response()->json(['contracts' => []]);
            }

            $contracts = $installments->map(function($item) {
                $today = Carbon::today();
                return [
                    'id' => $item->id,
                    'contract_number' => $item->contract_number,
                    'gold_amount' => (float) $item->gold_amount,
                    'installment_period' => (int) ($item->installment_period ?? 0),
                    'daily_payment_amount' => (float) ($item->daily_payment_amount),
                    'total_installment_amount' => (float) ($item->total_with_interest),
                    'total_paid' => (float) ($item->total_paid),
                    'due_this_period' => (float) ($item->due_amount_this_period ?? 0),
                    'overdue_amount' => (float) ($item->overdue_amount ?? 0),
                    'total_due_amount' => (float) ($item->total_due_amount ?? 0),
                    'next_due_date_custom' => $item->next_due_date_custom ?? null,
                    'down_payment' => (float) ($item->down_payment ?? 0),
                    'initial_payment' => (float) ($item->initial_payment ?? 0),
                    'payment_per_period' => (float) ($item->payment_per_period ?? 0),
                    'start_date' => $item->start_date,
                    'status' => $item->status,
                    'days_passed' => $item->start_date
                        ? Carbon::parse($item->start_date)->diffInDays($today) + 1
                        : 0,
                    'installment_payments' => $item->installmentPayments->map(function($p) {
                        return [
                            'id' => $p->id,
                            'amount' => (float) $p->amount,
                            'amount_paid' => (float) $p->amount_paid,
                            'status' => $p->status,
                            'payment_due_date' => $p->payment_due_date,
                            'created_at' => $p->created_at,
                        ];
                    })->values(),
                ];
            })->values();

            return response()->json(['contracts' => $contracts]);
        } catch (\Throwable $e) {
            // ตอบกลับแบบไม่พัง (แต่ log error ให้ debug)
            \Log::error('[API] DASHBOARD ERROR: ' . $e->getMessage() . ' LINE ' . $e->getLine());
            return response()->json(['contracts' => [], 'error' => $e->getMessage()], 200);
        }
    }
}
