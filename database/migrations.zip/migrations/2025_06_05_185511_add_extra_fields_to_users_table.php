<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'surname')) {
                $table->string('surname');
            }
            if (!Schema::hasColumn('users', 'phone')) {
                $table->string('phone')->unique();
            }
            if (!Schema::hasColumn('users', 'id_card_number')) {
                $table->string('id_card_number')->unique();
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['surname', 'phone', 'id_card_number']);
        });
    }
};
