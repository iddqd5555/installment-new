<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('installment_requests', function (Blueprint $table) {
            $table->float('interest_rate')->default(3.5); // ดอกเบี้ยที่ Admin ตั้งค่าได้
            $table->float('fine_rate')->default(1.5); // อัตราค่าปรับที่ Admin ตั้งค่าได้
            $table->date('next_payment_date')->nullable(); // วันนัดชำระถัดไป
            $table->float('total_with_interest')->default(0); // จำนวนเงินรวมรวมดอกเบี้ย
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('installment_requests', function (Blueprint $table) {
            $table->dropColumn(['interest_rate', 'fine_rate', 'next_payment_date', 'total_with_interest']);
        });
    }
};
