@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h2 class="text-center">📱 ผ่อน iPhone เร็วๆ นี้!</h2>
    <div class="alert alert-info text-center mt-4">
        📢 ระบบการผ่อน iPhone กำลังจะเปิดให้บริการเร็วๆ นี้ โปรดติดตาม!
    </div>
</div>
@endsection
