<?php

namespace App\Filament\Resources\PaymentQrLogResource\Pages;

use App\Filament\Resources\PaymentQrLogResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePaymentQrLog extends CreateRecord
{
    protected static string $resource = PaymentQrLogResource::class;
}
