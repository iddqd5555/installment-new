<?php

namespace App\Filament\Resources\InstallmentPaymentResource\Pages;

use App\Filament\Resources\InstallmentPaymentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInstallmentPayment extends CreateRecord
{
    protected static string $resource = InstallmentPaymentResource::class;
}
