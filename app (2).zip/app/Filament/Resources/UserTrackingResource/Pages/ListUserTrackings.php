<?php

namespace App\Filament\Resources\UserTrackingResource\Pages;

use App\Filament\Resources\UserTrackingResource;
use Filament\Resources\Pages\ListRecords;

class ListUserTrackings extends ListRecords
{
    protected static string $resource = UserTrackingResource::class;
}
