<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\InstallmentPayment;
use App\Models\User;
use App\Models\Admin;
use Carbon\Carbon;

class InstallmentRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'product_name', 'gold_amount', 'approved_gold_price',
        'installment_period', 'interest_rate', 'status', 'total_paid',
        'remaining_amount', 'approved_by', 'total_gold_price',
        'total_with_interest', 'daily_payment_amount', 'interest_amount',
        'daily_penalty', 'total_penalty', 'first_approved_date',
        'advance_payment', 'contract_number', 'payment_number', 'responsible_staff'
    ];

    // --- RELATION ---
    public function payments()
    {
        return $this->hasMany(InstallmentPayment::class);
    }

    public function installmentPayments()
    {
        return $this->hasMany(InstallmentPayment::class, 'installment_request_id');
    }

    public function approvedPayments()
    {
        return $this->payments()->where('status', 'approved');
    }

    public function user()
    {
        return $this->belongsTo(User::class)->withDefault();
    }

    public function approvedBy()
    {
        return $this->belongsTo(Admin::class, 'approved_by')->withDefault();
    }

    // --- BUSINESS CALCULATION ---
    public function getTotalGoldPriceAttribute()
    {
        return round($this->gold_amount * $this->approved_gold_price, 2);
    }

    public function getInterestRateFactorAttribute()
    {
        $rates = [30 => 1.27, 45 => 1.45, 60 => 1.66];
        return $rates[$this->installment_period] ?? 1;
    }

    public function getTotalWithInterestAttribute()
    {
        return round($this->total_gold_price * $this->interest_rate_factor, 2);
    }

    public function getInterestAmountAttribute()
    {
        return round($this->total_with_interest - $this->total_gold_price, 2);
    }

    public function getAdvancePaymentAttribute($value)
    {
        return $value ?: 0;
    }

    // --- DYNAMIC STAT ---
    public function getTotalPaidAttribute()
    {
        return $this->installmentPayments()->where('status', 'paid')->sum('amount_paid');
    }

    public function getRealRemainingAmountAttribute()
    {
        return $this->total_with_interest - $this->total_paid;
    }

    public function getTotalPenaltyAttribute()
    {
        $today = Carbon::today()->format('Y-m-d');
        $pending = $this->installmentPayments()->where('status', 'pending')->where('payment_due_date', '<', $today)->count();
        return $pending * ($this->daily_penalty ?? 0);
    }

    public function getPaymentHistoryAttribute()
    {
        return $this->installmentPayments()->orderBy('payment_due_date', 'desc')->take(20)->get();
    }

    public function getNextPaymentDateAttribute()
    {
        $today = Carbon::today()->format('Y-m-d');
        $next = $this->installmentPayments()->where('status', 'pending')->where('payment_due_date', '>=', $today)->orderBy('payment_due_date')->first();
        return $next ? $next->payment_due_date : null;
    }

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($request) {
            $lastId = self::max('id') ?? 0;
            $request->contract_number = 'A' . str_pad((68000 + $lastId + 1), 5, '0', STR_PAD_LEFT);
            $request->payment_number = 'INV' . now()->format('ym') . str_pad(($lastId + 1), 4, '0', STR_PAD_LEFT);
        });
    }

    // ด้านใน class InstallmentRequest (ต่อจาก function อื่นๆ)
    public function generatePayments()
    {
        $startDate = \Carbon\Carbon::parse($this->start_date);
        $period = intval($this->installment_period ?? 0);

        $amount = floatval($this->daily_payment_amount); // ตอนนี้ attribute จะใช้ค่าจาก DB จริง ๆ แล้ว

        if (!$amount || $amount <= 0) {
            $amount = 0;
        }

        \App\Models\InstallmentPayment::where('installment_request_id', $this->id)->delete();

        for ($i = 0; $i < $period; $i++) {
            $dueDate = $startDate->copy()->addDays($i)->setTime(9, 0, 0);
            \App\Models\InstallmentPayment::create([
                'installment_request_id' => $this->id,
                'amount' => $amount,
                'amount_paid' => 0,
                'payment_status' => 'pending',
                'status' => 'pending',
                'payment_due_date' => $dueDate,
                'ref' => 'PM' . $this->id . str_pad($i + 1, 4, '0', STR_PAD_LEFT),
            ]);
        }
    }

}
