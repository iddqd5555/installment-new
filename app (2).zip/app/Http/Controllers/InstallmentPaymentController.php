<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\InstallmentRequest;
use App\Models\InstallmentPayment;
use App\Models\BankAccount;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class InstallmentPaymentController extends Controller
{
    public function pay(Request $request)
    {
        $request->validate([
            'installment_request_id' => $request->has('pay_for_dates') ? 'required|integer' : 'nullable|integer',
            'pay_for_dates' => $request->has('installment_request_id') ? 'required|array' : 'nullable|array',
            'pay_for_dates.*' => 'date',
            'slip' => 'required|image|mimes:jpeg,png,jpg|max:5120',
        ]);

        // Save slip file
        $file = $request->file('slip');
        $imgPath = $file->store('slips', 'public');
        $imgFullPath = storage_path('app/public/' . $imgPath);

        // Run OCR+QR script
        $cmd = 'python ' . escapeshellarg(base_path('read_slip.py')) . ' ' . escapeshellarg($imgFullPath);
        $output = shell_exec($cmd);
        Log::info("SLIP OCR OUTPUT: " . $output);
        $result = json_decode($output, true);
        Log::info("SLIP OCR JSON: " . print_r($result, true));

        $ocrAmount = floatval($result['amount'] ?? 0);
        if ($ocrAmount <= 0) {
            return response()->json([
                'success' => false,
                'message' => 'ระบบไม่สามารถอ่านยอดเงินจากสลิปได้ กรุณาอัปโหลดภาพใหม่ หรือรอแอดมินตรวจสอบ'
            ], 200);
        }

        $imgHash = $result['slip_hash'] ?? md5_file($file->getRealPath());
        if (InstallmentPayment::where('slip_hash', $imgHash)->exists()) {
            return response()->json([
                'success' => false,
                'used' => true,
                'message' => '❌ สลิปนี้ถูกใช้แล้ว คุณไม่สามารถอัพโหลดสลิปซ้ำได้'
            ], 200);
        }

        // ===== ตรวจสอบเลขบัญชีปลายทาง (OCR กับในฐานข้อมูลบริษัท) =====
        $accountOCR = preg_replace('/[^0-9]/', '', $result['account'] ?? '');
        $matchedAccount = null;
        if ($accountOCR && strlen($accountOCR) >= 4) {
            $bankAccounts = BankAccount::all();
            foreach ($bankAccounts as $bank) {
                $accountDB = preg_replace('/[^0-9]/', '', $bank->account_number);
                // 1. match เต็ม (OCR กับ DB)
                if ($accountOCR === $accountDB) {
                    $matchedAccount = $bank;
                    break;
                }
                // 2. match 4-6 ตัวท้าย (เช่น 0811, 8116)
                for ($len = 4; $len <= 6; $len++) {
                    if (strlen($accountOCR) == $len && substr($accountDB, -$len) === $accountOCR) {
                        $matchedAccount = $bank;
                        break 2;
                    }
                }
                // 3. match 6-8 ตัวกลาง (เช่น 86xxxx8116, 8651xxxx16)
                if (strlen($accountDB) >= 8 && strlen($accountOCR) >= 6 && strpos($accountDB, $accountOCR) !== false) {
                    $matchedAccount = $bank;
                    break;
                }
                // 4. พร้อมเพย์ (เบอร์ 10 หลัก หรือเลข 15 หลัก)
                if ((strlen($accountDB) == 10 || strlen($accountDB) == 15) && $accountOCR === $accountDB) {
                    $matchedAccount = $bank;
                    break;
                }
            }
        }

        if (!$matchedAccount) {
            return response()->json([
                'success' => false,
                'message' => 'เลขบัญชีปลายทางในสลิปไม่ตรงกับระบบ กรุณาตรวจสอบเลขบัญชีบริษัท หรือรอแอดมินตรวจสอบ'
            ], 200);
        }
        // ===== END ตรวจสอบเลขบัญชีปลายทาง =====

        // ========== เติมเงินเข้ากระเป๋าสัญญา (advance) ==========
        if (empty($request->installment_request_id) || empty($request->pay_for_dates)) {
            $mainContract = InstallmentRequest::where('user_id', auth()->id())
                ->where('status', 'approved')
                ->latest('id')
                ->first();

            if (!$mainContract) {
                return response()->json([
                    'success' => false,
                    'message' => 'ไม่พบสัญญาที่สามารถเติมเงินได้ กรุณาติดต่อแอดมิน'
                ], 200);
            }

            $mainContract->advance_payment += $ocrAmount;
            $mainContract->save();

            InstallmentPayment::create([
                'installment_request_id' => $mainContract->id,
                'amount' => 0,
                'amount_paid' => 0,
                'payment_status' => 'advance',
                'status' => 'advance',
                'payment_proof' => $imgPath,
                'slip_hash' => $imgHash,
                'slip_reference' => $result['reference'] ?? null,
                'slip_qr_text' => $result['qr_text'] ?? null,
                'slip_ocr_json' => json_encode($result, JSON_UNESCAPED_UNICODE),
                'payment_due_date' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'เติมเงินสำเร็จ',
                'advance_payment' => $mainContract->advance_payment
            ]);
        }

        // ========== จ่ายผ่อนงวด (แบบระบุงวด) ==========
        $installment = InstallmentRequest::findOrFail($request->installment_request_id);

        $pendingPayments = InstallmentPayment::where('installment_request_id', $installment->id)
            ->where('status', 'pending')
            ->orderBy('payment_due_date')
            ->get();

        if ($pendingPayments->isEmpty()) {
            return response()->json(['message' => 'ไม่พบบิลที่ต้องจ่าย'], 200);
        }

        $totalPay = $ocrAmount + floatval($installment->advance_payment);
        $installment->advance_payment = 0;

        foreach ($pendingPayments as $idx => $payment) {
            if ($totalPay <= 0) break;
            $due = floatval($payment->amount) - floatval($payment->amount_paid);
            if ($due <= 0) continue;

            $payThisBill = min($due, $totalPay);
            $payment->amount_paid += $payThisBill;

            if ($payment->amount_paid >= $payment->amount) {
                $payment->status = 'paid';
                $payment->payment_status = 'paid';
            }

            if ($idx === 0 || empty($payment->payment_proof)) {
                $payment->payment_proof = $imgPath;
                $payment->slip_hash = $imgHash;
                $payment->slip_reference = $result['reference'] ?? null;
                $payment->slip_qr_text = $result['qr_text'] ?? null;
                $payment->slip_ocr_json = json_encode($result, JSON_UNESCAPED_UNICODE);
                $payment->admin_notes = null;
            }
            $payment->save();

            $totalPay -= $payThisBill;
        }

        if ($totalPay > 0) {
            $installment->advance_payment += $totalPay;
        }

        $installment->total_paid = InstallmentPayment::where('installment_request_id', $installment->id)
            ->where('status', 'paid')->sum('amount_paid');

        $installment->remaining_amount = $installment->total_installment_amount - $installment->total_paid;
        $installment->save();

        return response()->json([
            'success' => true,
            'message' => 'บันทึกการชำระเงินสำเร็จ',
            'advance_payment' => $installment->advance_payment
        ]);
    }

    // ดึงบิลค้างจ่าย (ให้ user ดู)
    public function pendingPayments(Request $request)
    {
        $request->validate([
            'installment_request_id' => 'required|integer',
        ]);

        $pending = InstallmentPayment::where('installment_request_id', $request->installment_request_id)
            ->where('status', 'pending')
            ->orderBy('payment_due_date')
            ->get();

        return response()->json($pending);
    }

    public function overdue(Request $request)
    {
        $id = $request->query('installment_request_id');
        $installment = InstallmentRequest::findOrFail($id);

        $overdue = InstallmentPayment::where('installment_request_id', $installment->id)
            ->where('payment_status', '!=', 'paid')
            ->whereDate('payment_due_date', '<', now())
            ->orderBy('payment_due_date')
            ->get(['id','amount','amount_paid','payment_due_date','status']);

        return response()->json(['overdue' => $overdue]);
    }

    public function userHistory(Request $request)
    {
        $userId = auth()->id();
        $installmentIds = InstallmentRequest::where('user_id', $userId)->pluck('id');
        $payments = InstallmentPayment::whereIn('installment_request_id', $installmentIds)
            ->orderBy('payment_due_date')
            ->get([
                'id', 'installment_request_id', 'amount', 'amount_paid', 'payment_due_date',
                'status', 'payment_status', 'payment_proof'
            ]);
        return response()->json(['history' => $payments]);
    }

    public function history(Request $request)
    {
        $id = $request->query('installment_request_id');
        $installment = InstallmentRequest::findOrFail($id);

        $payments = InstallmentPayment::where('installment_request_id', $installment->id)
            ->orderBy('payment_due_date')
            ->get([
                'id',
                'amount',
                'amount_paid',
                'payment_due_date',
                'status',
                'payment_status',
                'payment_proof'
            ]);

        return response()->json(['history' => $payments]);
    }
}
